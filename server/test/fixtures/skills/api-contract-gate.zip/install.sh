# harmless placeholder — never executed, demonstrates the import trust gate
